<section>
  <h1><?php echo $judul ?></h1>
  <h4>Nama</h4>
  <ul type="disc">
    <li>Nama Depan : Indra</li>
    <li>Nama Belakang : Ardiansyah</li>
  </ul>
  <br>
  <h4>Alamat</h4>
  <ul type="none">
    <li>Kp. Pulojahe, Jatinegara , Jakarta Timur</li>
  </ul>
  <h4>Tempat Lahir</h4>
  <ul type="none">
    <li>Magetan</li>
  </ul>
  <h4>Olahraga Favorite</h4>
  <ul type="square">
    <li>Running</li>
    <li>Climbing</li>
  </ul>
</section>